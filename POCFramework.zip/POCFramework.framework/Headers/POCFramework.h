//
//  POCFramework.h
//  POCFramework
//
//  Created by Raissa Nucci on 25/09/18.
//  Copyright © 2018 Raissa Nucci. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for POCFramework.
FOUNDATION_EXPORT double POCFrameworkVersionNumber;

//! Project version string for POCFramework.
FOUNDATION_EXPORT const unsigned char POCFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <POCFramework/PublicHeader.h>


